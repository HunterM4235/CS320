package taskMain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    // tests that a task is created successfully
    @Test
    void testValidTaskCreation() {
        Task task = new Task("12345", "Name", "Description");
        assertEquals("12345", task.getTaskID());
        assertEquals("Name", task.getName());
        assertEquals("Description", task.getDescription());
    }

    // tests that a null task ID throws an exception
    @Test
    void testNullTaskIDThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
    }

    // tests that a task ID longer than 10 char throws an exception
    @Test
    void testTooLongTaskIDThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ABCDEFGHIJK", "Name", "Description");
        });
    }

    // tests that a task ID with exactly 10 char is valid
    @Test
    void testMaxLengthTaskIDValid() {
        Task task = new Task("1234567890", "Name", "Description");
        assertEquals(10, task.getTaskID().length());
    }

    // tests that a null name throws an exception
    @Test
    void testNullNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Description");
        });
    }

    // tests that a name longer than 20 char throws an exception
    @Test
    void testTooLongNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "ThisNameIsWayTooLong12345", "Description");
        });
    }

    // tests that a name with exactly 20 char is valid
    @Test
    void testMaxLengthNameValid() {
        Task task = new Task("123", "A".repeat(20), "Description");
        assertEquals(20, task.getName().length());
    }

    // tests that setting a valid name updates the task correctly
    @Test
    void testSetValidName() {
        Task task = new Task("123", "OldName", "Description");
        task.setName("NewName");
        assertEquals("NewName", task.getName());
    }

    // tests that setting an invalid name throws an exception
    @Test
    void testSetInvalidNameThrowsException() {
        Task task = new Task("123", "OldName", "Description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("ThisNameIsWayTooLong12345");
        });
    }

    // tests that a null description throws an exception
    @Test
    void testNullDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", null);
        });
    }

    // tests that a description longer than 50 char throws an exception
    @Test
    void testTooLongDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", "A".repeat(51));
        });
    }

    // tests that a description with exactly 50 char is valid 
    @Test
    void testMaxLengthDescriptionValid() {
        Task task = new Task("123", "Name", "A".repeat(50));
        assertEquals(50, task.getDescription().length());
    }

    // tests that setting a valid description updates the task correctly
    @Test
    void testSetValidDescription() {
        Task task = new Task("123", "Name", "Old Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    // tests that setting an invalid description throws an exception
    @Test
    void testSetInvalidDescriptionThrowsException() {
        Task task = new Task("123", "Name", "Old Description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("A".repeat(60));
        });
    }
}