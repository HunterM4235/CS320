package taskMain;

public class Task {
	
	 private final String taskID;
	    private String name;
	    private String description;
	    
	    public Task(String taskID, String name, String description) {

	        //Validate Task ID
	        if (taskID == null || taskID.length() > 10) {
	            throw new IllegalArgumentException("Invalid Task ID");
	        }

	        //Validate Name
	        if (name == null || name.length() > 20) {
	            throw new IllegalArgumentException("Invalid Task Name");
	        }

	        //Validate Description
	        if (description == null || description.length() > 50) {
	            throw new IllegalArgumentException("Invalid Task Description");
	        }

	        this.taskID = taskID;
	        this.name = name;
	        this.description = description;
	    }

	    //Getters
	    public String getTaskID() {
	        return taskID;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getDescription() {
	        return description;
	    }

	    
	    public void setName(String name) {
	        if (name == null || name.length() > 20) {
	            throw new IllegalArgumentException("Invalid Task Name");
	        }
	        this.name = name;
	    }

	    public void setDescription(String description) {
	        if (description == null || description.length() > 50) {
	            throw new IllegalArgumentException("Invalid Task Description");
	        }
	        this.description = description;
	    }
	}


