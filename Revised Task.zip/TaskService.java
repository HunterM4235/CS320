package taskMain;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private Map<String, Task> tasks = new HashMap<>();

    // adds a task if the task ID is unique
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskID())) {
            throw new IllegalArgumentException("Task ID already exists!");
        }
        tasks.put(task.getTaskID(), task);
    }

    // deletes a task if task ID exists
    public void deleteTask(String taskID) {
        if (!tasks.containsKey(taskID)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(taskID);
    }

    // retrieves task by ID
    public Task getTask(String taskID) {
        if (!tasks.containsKey(taskID)) {
            throw new IllegalArgumentException("Task not found");
        }
        return tasks.get(taskID);
    }

    // updates the name of an existing task
    public void updateTaskName(String taskID, String newName) {
        Task task = getTask(taskID);
        task.setName(newName);
    }

    // updates the description of an existing task
    public void updateTaskDescription(String taskID, String newDescription) {
        Task task = getTask(taskID);
        task.setDescription(newDescription);
    }
}