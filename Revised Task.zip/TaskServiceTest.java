package taskMain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    // tests that task is successfully added
    @Test
    void testAddTaskSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("1", "TaskName", "TaskDescription");

        service.addTask(task);

        assertNotNull(service.getTask("1"));
        assertEquals("TaskName", service.getTask("1").getName());
    }

    // tests that duplicate task IDs throw an exception
    @Test
    void testAddTaskWithDuplicateIDThrowsException() {
        TaskService service = new TaskService();

        Task task1 = new Task("1", "Name1", "Desc1");
        Task task2 = new Task("1", "Name2", "Desc2");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    // tests that a task is deleted
    @Test
    void testDeleteTaskSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Name", "Description");

        service.addTask(task);
        service.deleteTask("1");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask("1");
        });
    }

    // tests that deleting a non-existent task throws an exception
    @Test
    void testDeleteNonExistentTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }

    // tests that the task name is updated
    @Test
    void testUpdateTaskNameSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("1", "OldName", "Description");

        service.addTask(task);
        service.updateTaskName("1", "NewName");

        assertEquals("NewName", service.getTask("1").getName());
    }

    // tests invalid name updates throw exceptions
    @Test
    void testUpdateTaskNameWithInvalidNameThrowsException() {
        TaskService service = new TaskService();
        Task task = new Task("1", "OldName", "Description");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("1", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("1", "ThisNameIsWayTooLong12345");
        });
    }

    // tests updating a non-existent task throws exception
    @Test
    void testUpdateTaskNameForNonexistentTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("999", "NewName");
        });
    }

    // tests that the task description is updated 
    @Test
    void testUpdateTaskDescriptionSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Name", "OldDesc");

        service.addTask(task);
        service.updateTaskDescription("1", "New Description");

        assertEquals("New Description", service.getTask("1").getDescription());
    }

    // tests invalid description updates throw exceptions
    @Test
    void testUpdateTaskDescriptionInvalidThrowsException() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Name", "OldDesc");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("1", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("1", "A".repeat(80));
        });
    }

    // tests updating a non-existent description throws exception
    @Test
    void testUpdateTaskDescriptionForNonexistentTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("999", "NewDesc");
        });
    }
}