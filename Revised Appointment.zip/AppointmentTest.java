package appointmentMain;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate;

    @BeforeEach
    public void setup() {
        // create a future date for valid appointment tests
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        futureDate = cal.getTime();
    }

    // tests valid appointment creation
    @Test
    public void testValidAppointmentCreation() {
        Appointment appt = new Appointment("A123", futureDate, "Regular checkup");

        assertEquals("A123", appt.getAppointmentID());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Regular checkup", appt.getDescription());
    }

    // tests appointment ID too long
    @Test
    public void testAppointmentIDTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Too long ID");
        });
    }

    // tests null appointment ID
    @Test
    public void testNullAppointmentID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Null ID");
        });
    }

    // tests past appointment date
    @Test
    public void testPastAppointmentDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Date pastDate = cal.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("PAST1", pastDate, "Past date");
        });
    }

    // tests null appointment date
    @Test
    public void testNullAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("NULL1", null, "Null date");
        });
    }

    // tests description too long 
    @Test
    public void testDescriptionTooLong() {
        String longDesc = "A".repeat(51);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("DESC1", futureDate, longDesc);
        });
    }

    // tests null description
    @Test
    public void testNullDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("NULL1", futureDate, null);
        });
    }

    // test exactly 50 character description is valid
    @Test
    public void testMaxLengthDescriptionValid() {
        String desc = "A".repeat(50);

        Appointment appt = new Appointment("A1", futureDate, desc);

        assertEquals(50, appt.getDescription().length());
    }

    
    @Test
    public void testAppointmentDateImmutability() {
        Appointment appt = new Appointment("A1", futureDate, "Test");

        Date returnedDate = appt.getAppointmentDate();
        returnedDate.setTime(0); 

        assertNotEquals(returnedDate, appt.getAppointmentDate());
    }
}