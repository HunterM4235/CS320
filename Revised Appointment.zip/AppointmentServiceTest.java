package appointmentMain;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Date futureDate;

    @BeforeEach
    public void setup() {
        service = new AppointmentService();

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        futureDate = cal.getTime();
    }

    // tests adding a valid appointment 
    @Test
    public void testAddValidAppointment() {
        Appointment appt = new Appointment("A1", futureDate, "Checkup");
        service.addAppointment(appt);

        assertEquals(appt, service.getAppointment("A1"));
    }

    // tests duplicate appointment IDs throw exception
    @Test
    public void testAddDuplicateAppointmentID() {
        Appointment appt1 = new Appointment("A2", futureDate, "First");
        Appointment appt2 = new Appointment("A2", futureDate, "Second");

        service.addAppointment(appt1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }

    // test appointment delete
    @Test
    public void testDeleteAppointment() {
        Appointment appt = new Appointment("DEL1", futureDate, "To delete");
        service.addAppointment(appt);

        service.deleteAppointment("DEL1");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("DEL1");
        });
    }

    // test deleting a non-existing appointment throws exception
    @Test
    public void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("NOPE");
        });
    }

   
    // test retrieving a non-extisting appointment throws exception
    @Test
    public void testGetNonexistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("INVALID");
        });
    }
}