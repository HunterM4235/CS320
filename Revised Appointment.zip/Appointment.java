package appointmentMain;

import java.util.Date;

public class Appointment {

    private final String appointmentID;
    private final Date appointmentDate;
    private final String description;

    public Appointment(String appointmentID, Date appointmentDate, String description) {

    	// validates appointment ID
        if (appointmentID == null || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        // validates appointment date
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        // validates description
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentID = appointmentID;
        this.appointmentDate = new Date(appointmentDate.getTime()); // FIX: defensive copy
        this.description = description;
    }

    // returns appointment ID
    public String getAppointmentID() {
        return appointmentID;
    }

    // returns appointment date
    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime()); // FIX: defensive copy
    }

    // returns description
    public String getDescription() {
        return description;
    }
}