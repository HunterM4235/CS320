package appointmentMain;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

	// stores appointment using appointment ID 
    private Map<String, Appointment> appointments = new HashMap<>();

    // adds new appointment
    public void addAppointment(Appointment appointment) {
        String id = appointment.getAppointmentID();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        appointments.put(id, appointment);
    }

    // deletes existing appointment, throws exception if ID does not exist
    public void deleteAppointment(String appointmentID) {
        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }
        appointments.remove(appointmentID);
    }

    // retrieves appointment by appointment ID, throws exception if appointment ID does not exist
    public Appointment getAppointment(String appointmentID) {
        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }
        return appointments.get(appointmentID);
    }
}